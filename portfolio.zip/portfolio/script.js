const menuToggle = document.getElementById('menu-toggle');
        const mobileNavbar = document.getElementById('mobile-navbar');

        menuToggle.addEventListener('click', () => {
            // Toggle the 'show' class
            mobileNavbar.classList.toggle('show');
        });


        //form

        const form = document.getElementById('contact-form');

        const formmini = document.getElementById('contact-form-mini');



  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const formData = new FormData(form);
    const data = Object.fromEntries(formData);

    try {
      const response = await fetch('https://portfolio-backend-ohio.onrender.com/send/mail', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      const result = await response.json();
      if (response.ok) {
        alert(result.message);
      } else {
        alert(result.error);
      }
    } catch (error) {
      alert('There was an error sending the email. Or the Backend Server is not Working');
    }
  });

//miniform subbmission
  formmini.addEventListener('submit', async (e) => {
    e.preventDefault();

    const formData = new FormData(formmini);
    const data = Object.fromEntries(formData);


    try {
      const response = await fetch('https://portfolio-backend-ohio.onrender.com/send/mail', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      const result = await response.json();
      if (response.ok) {
        alert(result.message);
      } else {
        alert(result.error);
      }
    } catch (error) {
      alert('There was an error sending the email. Or the Backend Server is not Working');
    }
  });



 // button view-more 
 const viewMoreBtn = document.getElementById('viewMoreBtn');
    const moreProjects = document.getElementById('moreProjects');

    let isExpanded = false; // To keep track of whether projects are shown or hidden

    viewMoreBtn.addEventListener('click', () => {
        isExpanded = !isExpanded; // Toggle the state
        moreProjects.classList.toggle('hidden', !isExpanded); // Show/hide more projects
        viewMoreBtn.textContent = isExpanded ? 'View Less' : 'View More'; // Change button text
    });


